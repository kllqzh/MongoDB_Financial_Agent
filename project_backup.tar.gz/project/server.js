// server.js
//
// This file is intentionally empty. You will fill it in during Lab 2 with
// help from Claude Code and the MongoDB Agent Skills.
//
// When you're done, run `npm start` to launch the server on port 3000.
